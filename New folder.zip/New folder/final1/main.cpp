/* 
 * File:   main.cpp
 * Author: Brandon Fins 
 * Created on June 6, 2016, 6:07 PM
 * Purpose:
 */

#include <iostream>

using namespace std;

//User Libraries

//Global Constants

//Function Prototypes
short convert(unsigned short);

int main() {
    unsigned short number=5;//the number to be converted
    do {
    cout<<"Enter a number between 0 and 65535."<<endl;//input validation for 
    //the unsigned short
    cin>>number;}//get the number
    while (number<0||number>65535);
    cout<<convert(number);//where the magic happens
    
    return 0;
}

short convert(unsigned short a){
    int remain, reverse=0;
    while (a!=0){//as long as a isnt 0
    remain=(a%10);//the remainder of a divided by 10
    reverse=(reverse*10+remain);//the new number get multiplied by 10, 
    //then the next number in the conversion gets added on to the end
    a/=10;}//actually divide by 10
    if (reverse<-32768||reverse>32767){//making sure the conversion 
        //falls within the range of shorts
        cout<<"No conversion possible."<<endl;
        return 0;
    }
    return reverse;
}
