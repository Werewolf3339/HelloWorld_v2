/* 
 * File:   main.cpp
 * Author: Brandon Fins 
 * Created on June 7, 2016, 10:04 PM
 * Purpose:
 */

#include <iostream>
#include <fstream>
#include <cstring>

using namespace std;

//User Libraries

//Global Constants

//Function Prototypes
int sort();

int main() {
    sort();
    
    return 0;
}

sort(){
    string one, two;
    char fill[10][15];
    ifstream input("input5.dat");//opens the file
    for (int i=0;i<10;i++){//rows
        for (int j=0;j<15;j++){//columns
            input>>fill[i][j];//fills the array
            cout<<fill[i][j];//prints the array
        }
        cout<<endl;//next line
    }
    input.close();//close the file
    cout<<endl<<endl;
    for(int y=0;y<10;y++){//makes sure it sorts 10 times
        for(int k=1;k<11;k++){//checking rows
            for(int l=0;l<15;l++){//checking columns   
                for(int p=0;p<15;p++){//creates the strings
                    one+=fill[k-1][p];//first string
                    two+=fill[k][p];//second string
                    if (one<two){//compares one and two
                        for(int h=0;h<15;h++){//swaps them if needed
                            swap(fill[k-1][h],fill[k][h]);
                        }
                    p=15;//if swapped, ceases to compare those 2 strings
                    break;//breaks the loop of comparing
                    }
                }
                one="";//resets the first string
                two="";//resets the second string
            }        
        }
    }
    for (int i=0;i<10;i++){
        for (int j=0;j<15;j++){
            cout<<fill[i][j];
        }
        cout<<endl;
    }    
}