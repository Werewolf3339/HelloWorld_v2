/* 
 * File:   main.cpp
 * Author: Brandon Fins 
 * Created on June 6, 2016, 7:04 PM
 * Purpose:
 */

#include <iostream>
#include <ctime>
#include <cstdlib>
#include <cmath>
#include <iomanip>

using namespace std;

//User Libraries

//Global Constants

//Function Prototypes

int main() {
    cout<<showpoint<<setprecision(0)<<fixed;
    int guesses, X, number,guess;//# of guesses, the power of 10, and the number
    srand(static_cast<unsigned int>(time(0)));//set the seed
    X=rand()%10+1;//x can be any number between 1 and 10
    guesses=static_cast<int>(X/log10(2));//rounding down the # of guesses
    cout<<"I have a number between 1 and "<<pow(10, X)<<endl<<"Can you guess "
        "my number?"<<endl<<"You will be given a maximum of "<<guesses
            <<" guesses."<<endl;
    int upper=pow(10, X);
    number=rand()%upper+1;//generating the random number from the range
    cout<<"Please type your first number"<<endl;
    for (int i=0;i<guesses;i++){
      cin>>guess;
      if (guess==number){
          cout<<"Congratulations, you've won!"<<endl;
      return 0;}
      if (guess<number){
          cout<<"Too low, try again."<<endl;}
      if (guess>number){
          cout<<"Too high, try again."<<endl;}
    }
    cout<<"Too many tries."<<endl;
    return 0;
}

