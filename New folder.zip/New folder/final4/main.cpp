/* 
 * File:   main.cpp
 * Author: Brandon Fins 
 * Created on June 7, 2016, 9:27 PM
 * Purpose:
 */

#include <iostream>
#include <ctime>
#include <iomanip>
#include <cstdlib>

using namespace std;

//User Libraries

//Global Constants

//Function Prototypes
int rando();//randomizes the number and spits out the info

int main() {
    rando();//running the function
    return 0;//all done
}

rando(){
    const int N=5;//array size
    short int rndseq[N]={9,61,88,101,121};//possible numbers to generate
    int freq[N]={0};//tracking the generation
    srand((time(0)));//set the seed for randomization
    for (int i=0;i<10000;i++){
        freq[rand()%5]++;}
    for (int j=0;j<N;j++){
        cout<<rndseq[j]<<" occured "<<freq[j]<<" times."<<endl;}
    }